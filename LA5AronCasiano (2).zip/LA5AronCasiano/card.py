from abc import ABC, abstractmethod

class Card(ABC):

    def isLargerThan(self,c):
        pass

    def Print_card(self):
        pass

