from abc import ABC, abstractclassmethod

class CardContainer(ABC):
     #no instructor
    def setInitNumofCards(self,n):
        pass

    def removeFirstCard(self):
        pass

    def getFirstCard(self):
        pass

    def addNewCard(self,c):
        pass

    #creates internal representation of deck of cards.owned by player 1/2
    #lofc is list of cards
    def addNewCards(self,lofc):
        pass

    def Get_cards(self):
        pass

    def get_cards_from_userview(self):
        pass



