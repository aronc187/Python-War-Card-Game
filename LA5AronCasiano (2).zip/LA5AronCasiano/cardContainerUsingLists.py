from cardConatianer import CardContainer
from intCard import intCard
from node import Node

class CardContainerUsingLists(CardContainer):
    def __init__(self):
        self.__head = None

    #remove head by setting head equal to head next node attribue
    def removeFirstCard(self):
        if self.__head == None:
            return False
        else:
            first = self.__head
            self.__head = self.__head.get_next()

    def set_head(self,value):
        self.__head = value

    def getFirstCard(self):
        return self.__head

    def addNewCard(self,c):
        # if c is an instance than it simply makes c head  if none or
        # make it head next value
        if isinstance(c, Node):
            if self.__head == None:
                self.__head = c
            else:
                current_node = self.__head

                while current_node.get_next() != None:
                    current_node = current_node.get_next()
                current_node.set_next(c)
        else:
            n = intCard()  # instance
            n.set_val(c)  # set card internal value to instance intCard

            if self.__head == None:
                passed_node = Node()  #node object
                passed_node.set_data(n) #set intCard object to Node data attribute
                self.__head = passed_node

            else:
                passed_node = Node()  #node object
                passed_node.set_data(n) #set intCard object to Node data attribute
                current_node = self.__head

                while current_node.get_next() != None:
                    current_node = current_node.get_next()
                current_node.set_next(passed_node)


    def addNewCards(self,lofc):
        # for tuple in lofc pass it to the addNewCard function
        for card in lofc:
            self.addNewCard(card)


    def Get_cards(self):
        #gets internal value by traversing through the linked list
        #and getting the intCard object value attribute
        internal_list = []
        temp = self.__head
        while temp != None:
            internal_val = temp.get_data().get_val()
            internal_list += [internal_val]
            temp = temp.get_next()
        return internal_list

    def get_cards_from_userview(self):
        user_list = []
        temp = self.__head
        #traversing through linked list and getting node intCard instance and getting internal value
        #and changin it to internal userview by subtracting it but its internal value suit range list
        while temp != None:
            internal_val = temp.get_data().get_val()
            Clubs = [x for x in range(1, 14)]
            Diamonds = [x for x in range(14, 27)]
            Hearts = [x for x in range(27, 40)]
            Spades = [x for x in range(40, 53)]
            face_value = [x for x in range(2, 15)]


            if internal_val in Clubs:
                user_list += [('Clubs', face_value[internal_val - 1] )]


            elif internal_val in Diamonds:
                user_list += [('Diamonds', face_value[internal_val - 14])]

            elif internal_val in Hearts:
                user_list += [('Hearts', face_value[internal_val - 27])]


            elif internal_val in Spades:
                user_list += [('Spades', face_value[internal_val - 40])]



            temp = temp.get_next()
        return user_list

