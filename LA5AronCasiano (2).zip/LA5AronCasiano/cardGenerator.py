import random
class CardGenerator:
    def generateCards(self,n):
        # when the user passes 'n' amount of cards, I use a for loop to loop from 1 to the 'n' number of cards.
        # each iteration will choose 1 internal number from (1,52) and add it to the empty list. which I do twice
        # for player 1 and player 2
        temp_list = [k for k in range(1, 53)]
        list_1 = []
        list_2 = []
        for x in range(1, n + 1):
            m = [random.choice(temp_list)]
            temp_list.remove(m[0])
            list_1 += m

        for num in range(1, n + 1):
            lst = [random.choice(temp_list)]
            temp_list.remove(lst[0])
            list_2 += lst

        # these are the internal numbers a
        # internal numbers in column
        Clubs = [x for x in range(1, 14)]
        Diamonds = [x for x in range(14, 27)]
        Hearts = [x for x in range(27, 40)]
        Spades = [x for x in range(40, 53)]
        face_value = [x for x in range(2, 15)]
        player_cards = []
        player_cards2 = []

        # for elements in list 1 index thier face value by indexing face_value and substracting a number
        # to index correct face value index position
        # i repeat the same for line 48-62
        for num in list_1:
            if num in Clubs:
                player_cards += [('Clubs', face_value[num - 1])]


            elif num in Diamonds:
                player_cards += [('Diamonds', face_value[num - 14])]

            elif num in Hearts:
                player_cards += [('Hearts', face_value[num - 27])]


            elif num in Spades:
                player_cards += [('Spades', face_value[num - 40])]

        for num2 in list_2:
            if num2 in Clubs:
                player_cards2 += [('Clubs', face_value[num2 - 1])]


            elif num2 in Diamonds:
                player_cards2 += [('Diamonds', face_value[num2 - 14])]

            elif num2 in Hearts:
                player_cards2 += [('Hearts', face_value[num2 - 27])]


            elif num2 in Spades:
                player_cards2 += [('Spades', face_value[num2 - 40])]

        #return generated list with n amount of userview cards
        return player_cards, player_cards2



