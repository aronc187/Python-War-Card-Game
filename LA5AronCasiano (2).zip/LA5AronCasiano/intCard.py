from card import Card
class intCard(Card):
    def get_val(self):
        return self.__value

    def set_val(self,card_val):
        #suit has tuple first element and value has tupe second element which is the face value
        suit = card_val[0]
        value = card_val[1]
        #this are list for the suits corresponding thier internal values
        Clubs = [x for x in range(1,14)]
        Diamonds = [x for x in range(14,27)]
        Hearts = [x for x in range(27,40)]
        Spades = [x for x in range(40,53)]

        #suit variable is equal to one of the suit strings then subtact 2 and index the
        #corresponding variable containing the suit internal numbers
        if suit == 'Clubs':
            self.__value = Clubs[value- 2 ]

        elif suit == 'Diamonds':
            self.__value = Diamonds[value - 2 ]

        elif suit == 'Hearts':
            self.__value = Hearts[value - 2]

        elif suit == 'Spades':
            self.__value = Spades[value-2]

    def isLargerThan(self,c):
        c_internalValue = c.get_val()
        Clubs = [x for x in range(1,14)]
        Diamonds = [x for x in range(14,27)]
        Hearts = [x for x in range(27,40)]
        Spades = [x for x in range(40,53)]
        face_value = [x for x in range(2,15)]

        #From line 38-52 I am using if/elif statements to convert self.__value into face value.
        # by subracting the initial value of thier list to index the correct face value
        if self.__value in Clubs:  # this is for the value of the object calling the function
            card_faceValue = face_value[self.__value - 1]


        elif self.__value in Diamonds:
            card_faceValue = face_value[self.__value - 14]

        elif self.__value in Hearts:
            card_faceValue = face_value[self.__value - 27]


        elif self.__value in Spades:
            card_faceValue = face_value[self.__value - 40]

        #From line 54-68 I am using if/elif statements to convert 'c' into face value.
        if c_internalValue in Clubs:
            card_C_faceValue = face_value[c_internalValue - 1]

        elif c_internalValue in Diamonds:
            card_C_faceValue = face_value[c_internalValue - 14]


        elif c_internalValue in Hearts:
            card_C_faceValue = face_value[c_internalValue - 27]


        elif c_internalValue in Spades:
            card_C_faceValue = face_value[c_internalValue - 40]


        #if both cards have same face value then I return 'tie' string

        if card_faceValue == card_C_faceValue:
            return 'tie'
        # else I return string 'current player' indicating the player that called the function wins
        #
        elif card_faceValue > card_C_faceValue:
            return 'current player'

        elif card_C_faceValue > card_faceValue:
            return 'other player'



