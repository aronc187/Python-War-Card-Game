from cardGenerator import CardGenerator
from cardContainerUsingLists import CardContainerUsingLists
from solver import Solver
from result import Print_Result
class Main:
    def main(self):
        #user enters number of cards
        n = int(input('Enter the number of cards for user 1 (1-26): '))
        print('user 2 will get the same number of cards from the deck.')
        print('User objects have been created!')
        print('Lets start the game!\n')
        #instance
        card_gen = CardGenerator()
        # return 'n' amount of random cards for user_1 and user_2
        user_1,user_2 = card_gen.generateCards(n)
        #table variable
        temp = CardContainerUsingLists()
        #instance
        u1 = CardContainerUsingLists()
        #instance
        u2 = CardContainerUsingLists()

        # add the 'n' amount of cards to u1 and u2 objects of CardContainerUsinglist class
        # you get a linked list with internal numbers
        u1.addNewCards(user_1)
        u2.addNewCards(user_2)

        # instance of Solve class
        solve1 = Solver()

        #acces Solve object set_p1 and set_p2 to set u1 and u2 as objects
        solve1.setP1(u1)
        solve1.setP2(u2)


        #set table at a
        solve1.setTable(temp)
        result = Print_Result()
        solve1.setPrint_Result(result)
        res, num_moves = solve1.solve()
        result.set_res(res)
        result.set_num_moves(num_moves)
        print('Game Over\n')
        result.print_output()

main_code = Main()
main_code.main()