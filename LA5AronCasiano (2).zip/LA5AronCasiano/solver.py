
class Solver:

    def solve(self):
        #steps is the step value
        steps = 0
        res = 0
        self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table) #prints step 0
        while steps < 100:

            player1_topCard = self.__user_1.getFirstCard()  # gets first player top cards
            player2_topCard = self.__user_2.getFirstCard()  # gets second player cards


            #Checks if step is 100 and compares user1 and user 2 list
            if steps == 100:
                res = 'tie'
                return res, steps


            #checks if players ran out of Cards
            if player1_topCard == None:
                res += 2
                self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                return res,steps
            elif player2_topCard == None:
                res += 1
                self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                return res,steps


            self.__user_1.removeFirstCard()  # remove player 1 card
            self.__user_2.removeFirstCard()  # remove player 2 carD
            player1_topCard.set_next(None)  # node next attribute equal none
            player2_topCard.set_next(None)  # node next attribute equal none
            self.__table.addNewCard(player1_topCard)  #add player 1 card to table                        #first face up cards
            self.__table.addNewCard(player2_topCard)  #add player 2 card to table



            #is larger than comparison if both equal then ends while loop and goes to war section
            winner = player1_topCard.get_data().isLargerThan(player2_topCard.get_data())

            #winner == 'current player' then add the cards to the player who called the isLargerThan()
            #Also if 'current player' player wins steps gets added by 1
            
            p = 0
            if winner == 'tie':
                while p != 1:
                    player_topCard1 = self.__user_1.getFirstCard()  # gets first player top cards
                    player_topCard2 = self.__user_2.getFirstCard()  # gets second player cards
                    if steps == 100:
                        res = 'tie'
                        return res, steps

                    if player_topCard1 == None:
                        res += 2
                        self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                        return res, steps
                    elif player_topCard2 == None:
                        res += 1
                        self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                        return res, steps
                    self.__user_1.removeFirstCard()  # remove player 1 card which is the face down            #second cards but face down cards
                    self.__user_2.removeFirstCard()  # remove player 2 card which is the face down
                    # node data cleared to none and added to the table linked list as p1 and p2 order
                    # from lines 40-43 is repeat of lines 11-14
                    player_topCard1.set_next(None)
                    player_topCard2.set_next(None)
                    self.__table.addNewCard(player_topCard1)  # add face down card of p1
                    self.__table.addNewCard(player_topCard2)  # add face down card of p2



                    # lines 44-52 are repeats of lines 33-42
                    # this part I am getting the third card to play war
                    player_topCard1 = self.__user_1.getFirstCard()  # gets first player top cards            #third cards but face up cards
                    player_topCard2 = self.__user_2.getFirstCard()  # gets second player cards
                    if steps == 100:
                        res = 'tie'
                        return res, steps

                    if player_topCard1 == None:
                        res += 2
                        self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                        return res, steps
                    elif player_topCard2 == None:
                        res += 1
                        self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                        return res, steps
                    self.__user_1.removeFirstCard()
                    self.__user_2.removeFirstCard()
                    player_topCard1.set_next(None)
                    player_topCard2.set_next(None)
                    self.__table.addNewCard(player_topCard1)  # add face up card of p1
                    self.__table.addNewCard(player_topCard2)  # add face up card of p2

                    win = player_topCard1.get_data().isLargerThan(
                    player2_topCard.get_data())  # using isLargetThan() on second face up card
                # from lines 45-55 are repeat lines of 19-29 to find the winner
                    if win == 'current player':
                        steps += 1
                        self.__print_result.print_step(steps, self.__user_1, self.__user_2,self.__table)  # Printing the step
                        passed_cards = self.__table.getFirstCard()
                        self.__user_1.addNewCard(passed_cards)
                        self.__table.set_head(None)
                        p = 1

                    elif win == 'other player':
                        steps += 1
                        self.__print_result.print_step(steps, self.__user_1, self.__user_2,self.__table)  # Printing the step
                        passed_cards = self.__table.getFirstCard()
                        self.__user_2.addNewCard(passed_cards)
                        self.__table.set_head(None)
                        p = 1

            elif winner == 'current player':
                steps += 1
                self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)  # Printing the step
                passed_cards = self.__table.getFirstCard() #  getting table head value
                self.__user_1.addNewCard(passed_cards)  # winner gets cards as p1 then p2 order
                self.__table.set_head(None)  # makes table linked list head attribute equal to none.

            #if winner == 'other player' then add the cards to the player who is in the isLargerThan()
            #Also if other player wins steps gets added by 1



            elif winner == 'other player':
                steps += 1
                self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)  # Printing the step
                passed_cards = self.__table.getFirstCard()
                self.__user_2.addNewCard(passed_cards)  # winner gets cards as p1 then p2 order
                self.__table.set_head(None)

            if steps == 100:
                res = 'tie'
                return res, steps


            #checks if players ran out of Cards
            if player1_topCard == None:
                res += 2
                self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                return res,steps
            elif player2_topCard == None:
                res += 1
                self.__print_result.print_step(steps, self.__user_1, self.__user_2, self.__table)
                return res,steps


    def setPrint_Result(self,p):
        self.__print_result = p


    def setP1(self,player1):
        self.__user_1 = player1

    # gets the player 1 CardContainerUsingLists object
    def getP1(self):
        return self.__user_1

    def setP2(self,player2):
        self.__user_2 = player2

    # gets the player 2 CardContainerUsingLists object
    def getP2(self):
        return self.__user_2

    def setTable(self,table):
        self.__table = table

    #gets the table CardContainerUsingLists object
    def getTable(self):
        return self.__table

